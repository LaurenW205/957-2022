import java.util.ArrayList;

import org.opencv.core.Mat;
import org.opencv.core.MatOfPoint;
import org.opencv.core.Rect;
import org.opencv.imgproc.Imgproc;

import edu.wpi.cscore.CvSink;
import edu.wpi.cscore.UsbCamera;
import edu.wpi.first.networktables.NetworkTable;
import edu.wpi.first.networktables.NetworkTableEntry;
import edu.wpi.first.networktables.NetworkTableInstance;

public class Vision {
    NetworkTableInstance inst = NetworkTableInstance.getDefault();
    NetworkTable table = inst.getTable("datatable");
    NetworkTableEntry txEntry = table.getEntry("tx");
    NetworkTableEntry radiusEntry = table.getEntry("radius");

    UsbCamera tracking_camera = new UsbCamera("tracking camera", 0);
    CvSink sink = new CvSink("sink");
    GripPipeline pipeline = new GripPipeline();
    double radius = 0;
    double centerx = 0;
    double centery = 0;

    public void loop(){
      sink.setSource(tracking_camera);
      tracking_camera.setExposureManual(15);  // Sets expsure of camera, can't be too low or too high
  
      while (true){
        ArrayList<MatOfPoint> data;
        try{
            data = processImage();  // Have gripPipeline process camera image and find targets
        }catch(Exception e){
            continue;
        }
        
        int targetAmount = data.size();
        if (targetAmount >= 3){                       // If there is not three targets in view, tracking can't be done
  
          // Get needed values from targets
            Rect t0 = Imgproc.boundingRect(data.get(0)); // Get X & Y of target 0
            int targetX0 = t0.x + (t0.width / 2);
            int targetY0 = t0.y + (t0.height / 2);
    
            Rect t1 = Imgproc.boundingRect(data.get(1));  // Get X & Y of target 1
            int targetX1 = t1.x + (t0.width / 2);
            int targetY1 = t1.y + (t0.height / 2);
    
            Rect t2 = Imgproc.boundingRect(data.get(2)); // Get X & Y of target 2
            int targetX2 = t2.x + (t0.width / 2);
            int targetY2 = t2.y + (t0.height / 2);

          // Process and send tracking data
            processPoints(targetX0, targetY0, targetX1, targetY1, targetX2, targetY2);
            if (centerx != -9000) // If data is not erroneous, send it out
              sendData();
    
          /* Testing prints
            if (centerx != -9000)
              System.out.println("Point: (" + centerx + ", " + centery + ")!");
          else {                                         
              centerx = -9000;
              centery = -9000;
              radius = -9000;
          }
          */
        }
      }
   }
      
      public ArrayList<MatOfPoint> processImage(){
    
        Mat mat = new Mat();
        sink.grabFrame(mat);
        pipeline.process(mat);
        ArrayList<MatOfPoint> data = pipeline.filterContoursOutput();
        return data;
    
      }
    
      public void processPoints(int targetX0, int targetY0, int targetX1, int targetY1, int targetX2, int targetY2){
        // Find midpoint between target 0 and 1
        double midpointX0 = (targetX0 + targetX1) / 2.0;
        double midpointY0 = (targetY0 + targetY1) / 2.0;
    
        // Find midpoint between target 0 and 2
        double midpointX1 = (targetX0 + targetX2) / 2.0;
        double midpointY1 = (targetY0 + targetY2) / 2.0;
    
        // Find values needed to use Cramer's rule to find the intersection between two lines (intersection is the center of circle)
        double a1 = (midpointX0 - targetX0);
        double b1 = (midpointY0 - targetY0);
        double c1 = - ( (midpointY0 - targetY0)*(midpointY0)*1.000000001 + (midpointX0 - targetX0)*(midpointX0)*1.000000001 );
        double a2 = (midpointX1 - targetX0);
        double b2 = (midpointY1 - targetY0);
        double c2 = - ( (midpointY1 - targetY0)*(midpointY1)*1.000000001 + (midpointX1 - targetX0)*(midpointX1)*1.00000001 );
    
        // Recognize erroneous data

        try{  // If there is a divide by 0 error, make data erroneous (set to values to -9000)
            centerx = ( b1*c2*1.0000001 - b2*c1*1.0000001 ) / ( a1*b2*1.0000001 - a2*b1*1.0000001 );
            centery = (c1*a2 - c2*a1) / (a1*b2 - a2*b1);
            radius = Math.sqrt( Math.pow((targetY0 - centerx), 2) + Math.pow((targetY0 - ( ( c1*a2 - c2*a1 ) / ( a1*b2 - a2*b1 ))), 2) );
        }catch(Exception e){
            centerx = -9000;
            radius = -9000;
        }
         if (centerx > 480 || centerx < -160 || centery > 360 || centery < -120){   // If calculated center point is way outside of camera bounds (320x240), make data erroneous (set to -9000)
              centerx = -9000;
              centery = -9000;
              radius = -9000;
         }
        
      }
    
      public void sendData(){
        txEntry.setDouble(centerx);
        radiusEntry.setDouble(radius);
      }
}